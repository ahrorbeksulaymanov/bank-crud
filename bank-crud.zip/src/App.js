import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'antd/dist/antd.css';
import 'react-super-responsive-table/dist/SuperResponsiveTableStyle.css';
import MyLayout from "./components/layout/index"
import LoginPage from './components/login/index'
import { useEffect } from 'react';
import { Routes, Route, useNavigate} from 'react-router-dom'
import RoutesMiddleware from './routes/reuterMiddleware';

function App() {

  const history = useNavigate()

  useEffect(() => {
    if(localStorage.getItem("token") && (localStorage.getItem("tokenExpiration") === 1645372769277)){
      history('/')
    }else{
      history('/login')
    }
  }, [])

  return (
    <div className="App">
        <RoutesMiddleware />
      {/* <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/" element={<MyLayout />} />
      </Routes> */}
    </div>
  );
}

export default App;
