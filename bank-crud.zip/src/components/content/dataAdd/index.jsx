import { CheckOutlined, LeftOutlined } from "@ant-design/icons";
import React, { useEffect, useState } from "react";
import "../style.scss";
import { Form, Input, Button, Select, message } from "antd";
import axios from "axios";
import { PATH_API } from "../../../constants";

const { Option } = Select;

const AddBank = () => {
  const [status, setStatus] = useState([]);

  useEffect(() => {
    const token = localStorage.getItem("token");
    axios({
      url: `http://templ-api.webase.uz/Helper/GetStateList`,
      method: "get",
      headers: {
        Authorization: "Bearer " + token,
      },
    }).then((res) => {
      setStatus(res?.data);
      console.log(res?.data);
    });
  }, []);

  const updateData = (val) => {
    const token = localStorage.getItem("token");
    axios({
        url: PATH_API + `/Bank/Update`,
        method: "POST",
        data: {
            id: 0,
            code: val.code,
            bankname :val.bankname,
            stateid: val.stateid
        },
        headers: {
            Authorization: "Bearer " + token,
          },
      }).then((res) => {
          if(res?.data?.success){
              message.success("Data is added!")
          }
      }).catch((err) => {
          message.error("Something is wrong!")
      })
  };

  return (
    <div className="bank-add-wrapper">
      <div>
        <Form
          name="basic"
          labelCol={{ span: 8 }}
          wrapperCol={{ span: 8 }}
          initialValues={{ remember: true }}
          onFinish={updateData}
          autoComplete="off"
        >
          <div className="d-flex justify-content-between align-items-center">
            <h5>Bank</h5>
            <div className="d-flex justify-content-end">
              <Button
                className="d-flex justify-content-between align-items-center me-2"
                type="primary"
              >
                <LeftOutlined />
                Back
              </Button>
              <Button
                className="d-flex justify-content-between align-items-center"
                type="primary"
                htmlType="submit"
              >
                <CheckOutlined />
                Save
              </Button>
            </div>
          </div>
          <hr className="mt-1 mb-4" />
          <Form.Item
            label="bank Code"
            name="code"
            rules={[{ required: true, message: "Please input bank Code!" }]}
          >
            <Input placeholder="input bank code, please" />
          </Form.Item>

          <Form.Item
            label="bank name"
            name="bankname"
            className="my-5"
            rules={[{ required: true, message: "Please input bank name!" }]}
          >
            <Input placeholder="input bank name, please" />
          </Form.Item>

          <Form.Item name="stateid" label="StateId" rules={[{ required: true }]}>
            <Select
              placeholder="Select a option and change input text above"
              allowClear
            >
              {status?.map((item, index) => (
                <Option value={item.id}>{item.name}</Option>
              ))}
            </Select>
          </Form.Item>
        </Form>
      </div>
    </div>
  );
};
export default AddBank;
