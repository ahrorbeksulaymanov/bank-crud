import React from "react";
import { Routes, Route, useNavigate} from 'react-router-dom'
import { all_routes } from ".";
import RenderComponent from "./renderRoutes";

const RoutesMiddleware = () => {


  return (
    <Routes>
        {
            all_routes.length && all_routes.map((item, index) => {
                console.log("item", item);
                return(
                    <RenderComponent
                        key={index}
                        path={item.path}
                        exact={item.exact}
                        component={item.component}
                        structure={item.config.structure}
                    />
                )
            })
        }
    </Routes>
  );
};
export default RoutesMiddleware;
